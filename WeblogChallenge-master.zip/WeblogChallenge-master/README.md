# Solution for WeblogChallenge

## Execution steps
execute.sh shell script can be executed with two parameters to submit the code to spark cluster on local machine. First parameter is log file path and second optional parameter is inactivity window minutes.
Ex. `./execute.sh data/2015_07_22_mktplace_shop_web_log_sample.log.gz 30`


## Arguments for application
1. Log file 
2. Time window during which inactivity means new session. This is optional and defaults to 15 minutes.

### Code uses below components

1. scala 2.12.8
2. spark 2.4.1
3. sbt 1.3.8

### Assumptions
1. Client IP and port along with user_agent details give unique session details.
2. Sessions with duration 0 are still sessions.
3. if user_agent information is null , it still is session as it has clientIP port details.

## Results with 15 minute inactivity window

```
1. Sessionize the web log by IP. Sessionize = aggregrate all page hits by visitor/IP during a session.

+-------------------+----------+--------------------+----------------+------------------+
|        client_port|session_id|          user_agent|session_duration|distinct_url_count|
+-------------------+----------+--------------------+----------------+------------------+
| 1.186.103.78:25143|         1|Mozilla/5.0 (Wind...|             505|                 4|
|  1.186.41.45:49818|         1|Mozilla/5.0 (comp...|               0|                 1|
|   1.186.79.5:57017|         1|Mozilla/5.0 (Wind...|               0|                 1|
| 1.186.85.235:28882|         1|Mozilla/5.0 (Wind...|               0|                 1|
|1.187.139.132:48211|         1|Mozilla/5.0 (Blac...|               0|                 1|
| 1.187.171.68:56669|         1|Mozilla/5.0 (Wind...|             959|                11|
|  1.187.226.89:2262|         1|Mozilla/5.0 (Linu...|               0|                 1|
| 1.187.229.29:55615|         1|Mozilla/5.0 (Andr...|               0|                 1|
|1.187.237.123:48326|         1|Mozilla/5.0 (Wind...|             711|                 2|
| 1.187.247.12:38711|         1|Mozilla/5.0 (Wind...|             608|                 2|
+-------------------+----------+--------------------+----------------+------------------+
only showing top 10 rows

2. Determine the average session time
+---------------------+
|avg(session_duration)|
+---------------------+
|   211.20888192172816|
+---------------------+

3. Determine unique URL visits per session.
+-------------------+----------+------------------+
|        client_port|session_id|distinct_url_count|
+-------------------+----------+------------------+
| 1.186.103.78:25143|         1|                 4|
|  1.186.41.45:49818|         1|                 1|
|   1.186.79.5:57017|         1|                 1|
| 1.186.85.235:28882|         1|                 1|
|1.187.139.132:48211|         1|                 1|
| 1.187.171.68:56669|         1|                11|
|  1.187.226.89:2262|         1|                 1|
| 1.187.229.29:55615|         1|                 1|
|1.187.237.123:48326|         1|                 2|
| 1.187.247.12:38711|         1|                 2|
+-------------------+----------+------------------+
only showing top 10 rows

4.Find the most engaged users.
+--------------+
|     client_ip|
+--------------+
| 119.81.61.166|
|  52.74.219.71|
|  125.19.44.66|
|  59.144.58.37|
|121.58.175.128|
|   61.246.57.5|
|  8.37.225.200|
| 116.50.59.180|
|  70.39.186.55|
|  203.91.192.4|
+--------------+
only showing top 10 rows ```

