import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._

object main {

  //Application params
  val APP_NAME = "WeblogChallenge"
  val ERROR_LEVEL = "ERROR"
  val SPARK_MASTER = "local[*]"
  val DEFAULT_SESSION_WINDOW_MIN = 15
  val UNIX_TIMESTAMP_COL = "unixTimestamp"

  //Schema values
  val TIMESTAMP_COL = "timestamp"
  val ELB = "elb"
  val CLIENT_PORT = "client_port"
  val BACKEND_PORT = "backend_port"
  val REQUEST_PROCESSING_TIME = "request_processing_time"
  val BACKEND_PROCESSING_TIME = "backend_processing_time"
  val RESPONSE_PROCESSING_TIME = "response_processing_time"
  val ELB_STATUS_CODE = "elb_status_code"
  val BACKEND_STATUS_CODE = "backend_status_code"
  val RECEIVED_BYTES = "received_bytes"
  val SENT_BYTES = "sent_bytes"
  val REQUEST = "request"
  val USER_AGENT = "user_agent"
  val SSL_CIPHER = "ssl_cipher"
  val SSL_PROTOCOL = "ssl_protocol"

  //Derived Values
  val SESSION_ID = "session_id"
  val SESSION_FLAG = "session_flag"
  val SESSION_DURATION = "session_duration"
  val DISTINCT_URL_COUNT = "distinct_url_count"
  val CLIENT_IP = "client_ip"
  val TOTAL_SESSION_DURATION = "Total_session_duration"

  val logSchema: StructType = StructType(Array(
    StructField(TIMESTAMP_COL, TimestampType, nullable = true),
    StructField(ELB, StringType, nullable = true),
    StructField(CLIENT_PORT, StringType, nullable = true),
    StructField(BACKEND_PORT, StringType, nullable = true),
    StructField(REQUEST_PROCESSING_TIME, DoubleType, nullable = true),
    StructField(BACKEND_PROCESSING_TIME, DoubleType, nullable = true),
    StructField(RESPONSE_PROCESSING_TIME, DoubleType, nullable = true),
    StructField(ELB_STATUS_CODE, StringType, nullable = true),
    StructField(BACKEND_STATUS_CODE, StringType, nullable = true),
    StructField(RECEIVED_BYTES, LongType, nullable = true),
    StructField(SENT_BYTES, LongType, nullable = true),
    StructField(REQUEST, StringType, nullable = true),
    StructField(USER_AGENT, StringType, nullable = true),
    StructField(SSL_CIPHER, StringType, nullable = true),
    StructField(SSL_PROTOCOL, StringType, nullable = true)
  ))

  def main(args: Array[String]): Unit = {
    if (args.length < 1) {
      System.err.println("Args Required: logfile [OPTIONAL_session_inactivity_time_window_minutes]")
      System.exit(1)
    }
    // Initializing spark session
    val spark = SparkSession.builder.appName(APP_NAME).master(SPARK_MASTER).getOrCreate()
    spark.sparkContext.setLogLevel(ERROR_LEVEL)

    // Loading log file into dataframe from arguments
    val logDataDf = spark.read.option("header", value = false).option("delimiter", " ").schema(logSchema).csv(args(0))
    // Filtering any records with null timestamp or IP as these records will not be moved to sessions.
    val filteredLogDataDF = logDataDf.filter(!(col(TIMESTAMP_COL).isNull) && !(col(CLIENT_PORT).isNull))

    // Get the session inactivity time window after which new session starts, from second argument or default to 15 minutes
    val sessionInactivityWindow =
      if (args.length >= 2) args(1) * 60 else DEFAULT_SESSION_WINDOW_MIN * 60


    println("Sessionize the web log by IP. Sessionize = aggregrate all page hits by visitor/IP during a session.")
    val windowExp = Window.partitionBy(CLIENT_PORT, USER_AGENT).orderBy(UNIX_TIMESTAMP_COL)
    val sessionsDF = filteredLogDataDF.withColumn(UNIX_TIMESTAMP_COL, unix_timestamp(col(TIMESTAMP_COL)))
      .withColumn(SESSION_FLAG, (col(UNIX_TIMESTAMP_COL) - (lag(col(UNIX_TIMESTAMP_COL), 1, 0).over(windowExp)) > (sessionInactivityWindow)).cast("long"))
      .withColumn(SESSION_ID, sum(SESSION_FLAG).over(windowExp))
      .drop(SESSION_FLAG)
    val sessionizedDf = sessionsDF.groupBy(CLIENT_PORT, SESSION_ID, USER_AGENT)
      .agg((max(UNIX_TIMESTAMP_COL) - min(UNIX_TIMESTAMP_COL)).alias(SESSION_DURATION), countDistinct(REQUEST).alias(DISTINCT_URL_COUNT))
      .cache()
    sessionizedDf.show(10)


    println("2. Determine the average session time")
    val averageSessionTimeDf: Unit = sessionizedDf.agg(avg(SESSION_DURATION)).show()

    println("3. Determine unique URL visits per session.")
    val urlPerSessionDf = sessionizedDf.select(CLIENT_PORT, SESSION_ID, DISTINCT_URL_COUNT)
    urlPerSessionDf.show(10)

    println("4.Find the most engaged users.")
    val engagedUsersDf = sessionizedDf.withColumn(CLIENT_IP, split(col(CLIENT_PORT), ":")(0)).groupBy(CLIENT_IP).agg(sum(SESSION_DURATION).alias(TOTAL_SESSION_DURATION)).orderBy(desc(TOTAL_SESSION_DURATION)).select(CLIENT_IP)
    engagedUsersDf.show(10)

    spark.stop()
  }

}
