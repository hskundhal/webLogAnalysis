#!/bin/bash
if [ $# -eq 0 ]; then
  echo "No arguments supplied"
  echo "Usage execute.sh logfile_full_path inactivity_window_minutes"
  echo "Atleast Full path for log File is needed"
  echo "inactivity_window_minutes is optional and will default to 15 minutes"
  exit 1
fi
# creating jar
sbt clean
sbt package

startTime=$(date +%s)

# logfile assignment
logFile=$1
echo " log file : $logFile"

# Inactivity Window minutes assignment or defaults to 15
if ! [ -z "$2" ]; then
  if [ $2 -ge 0 ]; then
    inactivityWindowDuration=$2
  else
    inactivityWindowDuration=15
  fi
else
  inactivityWindowDuration=15
fi
echo "inactivity window minutes : $inactivityWindowDuration"
# execution of code
$SPARK_HOME/bin/spark-submit --class "main" --master "local" target/scala-2.12/weblogchallenge_2.12-0.1.jar $logFile $inactivityWindowDuration

# capture Executiontime
endTime=$(date +%s)
totalTimeTaken=$((endTime - startTime))
echo "Execution duration: ${totalTimeTaken} seconds"
